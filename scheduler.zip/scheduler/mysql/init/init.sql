create database scheduler;

CREATE TABLE `broker` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `ip` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ip地址',
  `host_name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主机名',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uk_ip` (`ip`) USING BTREE
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT COMMENT='服务节点信息表';


CREATE TABLE `event` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project` varchar(64) NOT NULL COMMENT '项目名',
  `job_id` int(11) NOT NULL COMMENT '任务ID',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0:启动; 1:停止; 2: 手动触发一次',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='事件表';

CREATE TABLE `job_audit` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '工单id',
  `project` varchar(256) NOT NULL COMMENT '项目名称',
  `job_id` int(11) DEFAULT NULL COMMENT '任务id,如果是新增任务，审批完成，需要回填此id',
  `unique_code` varchar(254) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '任务唯一码',
  `submitter` varchar(256) CHARACTER SET utf8 NOT NULL COMMENT '申请人',
  `auditor` varchar(256) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '审核人',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '审批状态，0: 未审批，1:已审批，2:已驳回',
  `content` varchar(4096) CHARACTER SET utf8 NOT NULL DEFAULT '' COMMENT '工单内容',
  `comment` varchar(64) CHARACTER SET utf8 DEFAULT NULL COMMENT '本次变更对应的需求jira_id',
  `type` tinyint(1) NOT NULL COMMENT '工单类型，0: 新增任务，1: 修改任务',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_job_uniq_code` (`unique_code`) USING BTREE COMMENT '任务唯一码-查询索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='任务审批流程表';

CREATE TABLE `job_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `job_group` varchar(64) NOT NULL DEFAULT '' COMMENT '任务组',
  `job_name` varchar(64) NOT NULL DEFAULT '',
  `job_code` varchar(128) NOT NULL DEFAULT '' COMMENT '任务类',
  `job_method` varchar(128) NOT NULL DEFAULT '' COMMENT '任务方法',
  `job_args` varchar(1000) NOT NULL DEFAULT '' COMMENT 'job需要的参数',
  `job_uniq_code` varchar(256) NOT NULL DEFAULT '',
  `expression` varchar(64) NOT NULL DEFAULT '',
  `schedule_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0  未启动  1 启动',
  `group` varchar(128) NOT NULL DEFAULT '' COMMENT '任务的执行节点所属分组',
  `job_run_node` varchar(1000) NOT NULL DEFAULT '',
  `port` int(11) unsigned NOT NULL DEFAULT '0',
  `strategy_code` tinyint(4) DEFAULT '0' COMMENT '0 第一个节点 1 随机 2全部节点',
  `operator` varchar(32) DEFAULT NULL,
  `job_desc` varchar(1000) DEFAULT '' COMMENT 'job描述',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modify_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `project` varchar(64) DEFAULT NULL COMMENT '标准服务名,来源于服务中心',
  `job_owner` varchar(64) DEFAULT NULL,
  `max_run_time` int(11) DEFAULT NULL,
  `ldap_user` varchar(64) DEFAULT NULL,
  `last_modify_user` varchar(64) DEFAULT NULL,
  `job_level` tinyint(2) DEFAULT NULL,
  `tester` varchar(256) DEFAULT '' COMMENT 'job测试人员',
  `header_key` varchar(255) DEFAULT NULL,
  `header_value` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_job_uniq_code` (`job_uniq_code`(255)) USING BTREE COMMENT 'job的唯一索引',
  KEY `idx_project_status` (`job_group`,`schedule_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `node` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `project` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '应用名称',
  `profile` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT 'default' COMMENT '服务运行环境',
  `cloud` varchar(32) CHARACTER SET utf8 NOT NULL DEFAULT 'default' COMMENT '云机房名称',
  `group` varchar(128) CHARACTER SET utf8 NOT NULL COMMENT '任务的执行节点所属分组',
  `host_name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ip地址',
  `port` int(11) NOT NULL DEFAULT '0' COMMENT '服务端口号',
  `instance_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_version` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `host` varchar(33) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_project` (`project`) USING BTREE,
  KEY `idx_update_time` (`update_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT COMMENT='服务节点信息表';

CREATE TABLE `project` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(64) NOT NULL COMMENT '项目英文名',
  `language` tinyint(1) NOT NULL DEFAULT '1',
  `department_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `description` varchar(256) NOT NULL COMMENT '项目描述',
  `operator` varchar(64) DEFAULT NULL,
  `token` varchar(64) NOT NULL DEFAULT '',
  `audit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否审计',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `project_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project` varchar(64) NOT NULL DEFAULT '' COMMENT '项目名',
  `account_name` varchar(64) DEFAULT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_project_user` (`project`,`account_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `t_lock` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `namespace` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'ip地址',
  `owner` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '所属组',
  `version` bigint(20) NOT NULL DEFAULT '0' COMMENT '版本',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_ip` (`namespace`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT COMMENT='分布式锁表';


CREATE TABLE `t_trigger` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project` varchar(64) NOT NULL DEFAULT '' COMMENT '项目名',
  `job_id` int(11) NOT NULL COMMENT '任务ID',
  `ip` varchar(32) DEFAULT NULL COMMENT '任务分配ip',
  `version` int(11) NOT NULL DEFAULT '0' COMMENT '版本',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_ip` (`ip`) USING BTREE,
  KEY `idx_update_time` (`update_time`) USING BTREE
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='任务分配';


CREATE TABLE `trace` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `project` varchar(64) CHARACTER SET utf8mb4 NOT NULL COMMENT '项目名',
  `name` varchar(64) CHARACTER SET utf8mb4 NOT NULL COMMENT '任务名',
  `job_id` int(11) NOT NULL COMMENT '任务id',
  `clazz` varchar(64) CHARACTER SET utf8mb4 NOT NULL COMMENT '任务类',
  `method` varchar(64) CHARACTER SET utf8mb4 NOT NULL COMMENT '任务方法',
  `data` varchar(1024) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '任务参数',
  `unique_code` varchar(128) CHARACTER SET utf8mb4 NOT NULL COMMENT '任务唯一码',
  `trace_id` varchar(128) CHARACTER SET utf8mb4 NOT NULL COMMENT '追踪ID',
  `content` varchar(8192) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '追踪记录',
  `duration` int(11) NOT NULL DEFAULT '-1' COMMENT '任务耗时',
  `trigger_node` varchar(32) CHARACTER SET utf8mb4 NOT NULL COMMENT '任务出发节点',
  `total` int(11) NOT NULL DEFAULT '1' COMMENT '分片总数',
  `sc` int(11) NOT NULL DEFAULT '0' COMMENT '回调成功数',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_project_uniquecode` (`project`,`unique_code`) USING BTREE,
  KEY `idx_trace_id` (`trace_id`) USING BTREE,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='任务追踪表';






